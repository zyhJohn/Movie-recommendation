package com.zucc.zyh.dao;

import com.zucc.zyh.entity.AdminEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminDao extends BaseMapper<AdminEntity> {

}
