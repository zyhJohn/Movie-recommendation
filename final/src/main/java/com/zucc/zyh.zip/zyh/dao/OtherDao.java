package com.zucc.zyh.dao;

import com.zucc.zyh.entity.OtherEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OtherDao extends BaseMapper<OtherEntity> {

}
