package com.zucc.zyh.dao;

import com.zucc.zyh.entity.RatingsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RatingsDao extends BaseMapper<RatingsEntity> {

}
